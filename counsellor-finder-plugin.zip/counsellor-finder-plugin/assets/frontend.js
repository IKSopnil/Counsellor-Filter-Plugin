jQuery(document).ready(function ($) {
  const restUrl = cfData.restUrl + 'counsellors';
  const $results = $('#counsellor-results');
  const $filters = {
    specialty: $('#specialty-filter'),
    client_group: $('#client_group-filter'),
    location: $('#location-filter'),
  };

  /* ========= Fetch and Render Counsellors ========= */
  function fetchCounsellors(filters = {}) {
    $results.html('<p>Loading counsellors...</p>');

    // Remove empty filters
    Object.keys(filters).forEach((key) => {
      if (!filters[key]) delete filters[key];
    });

    $.get(restUrl, filters, function (response) {
      renderCounsellors(response.counsellors);
    }).fail(function () {
      $results.html('<p>Error loading counsellors. Please try again later.</p>');
    });
  }

  /* ========= Render Dropdown Filters (robust) ========= */
  function renderFilters() {
    const taxList = Object.keys($filters); // ['specialty','client_group','location']

    // Step 1: ask our plugin endpoint for term IDs collected from counsellor posts
    $.get(cfData.restUrl + 'counsellors')
      .done(function (resp) {
        // resp.terms should be { specialty: [ids...], client_group: [...], location: [...] }
        taxList.forEach((tax) => {
          const $select = $filters[tax];
          $select.find('option:not(:first)').remove(); // clear previous options except "All"

          const ids = Array.isArray(resp.terms && resp.terms[tax]) ? resp.terms[tax] : [];

          // Helper to append terms to select
          const appendTerms = (terms) => {
            terms.forEach((term) => {
              $select.append(`<option value="${term.id}">${term.name}</option>`);
            });
          };

          // If we have IDs from the plugin REST response, fetch those term details (faster & accurate)
          if (ids.length) {
            const includeParam = ids.join(',');
            $.get(`${wpApiSettings.root}wp/v2/${tax}?include=${includeParam}&per_page=100&hide_empty=false`)
              .done(function (terms) {
                if (Array.isArray(terms) && terms.length) {
                  appendTerms(terms);
                } else {
                  console.warn(`No terms returned for include(${includeParam}). Falling back to all terms for ${tax}.`);
                  fetchAllTermsAndAppend(tax, appendTerms);
                }
              })
              .fail(function (jqXHR, textStatus, err) {
                console.error(`Error fetching terms by include for ${tax}:`, textStatus, err);
                fetchAllTermsAndAppend(tax, appendTerms);
              });
          } else {
            fetchAllTermsAndAppend(tax, appendTerms);
          }
        });
      })
      .fail(function () {
        console.error('Could not reach plugin REST endpoint; falling back to fetching all terms directly.');
        taxList.forEach((tax) => {
          const $select = $filters[tax];
          $select.find('option:not(:first)').remove();
          fetchAllTermsAndAppend(tax, (terms) => {
            terms.forEach((term) => {
              $select.append(`<option value="${term.id}">${term.name}</option>`);
            });
          });
        });
      });

    // Helper: fetch all terms for a taxonomy, handling pagination
    function fetchAllTermsAndAppend(tax, appendCallback, page = 1, accum = []) {
      $.get(`${wpApiSettings.root}wp/v2/${tax}?per_page=100&page=${page}&hide_empty=false`)
        .done(function (terms, textStatus, xhr) {
          accum = accum.concat(terms || []);
          const totalPages = parseInt(xhr.getResponseHeader('X-WP-TotalPages') || '1', 10);
          if (page < totalPages) {
            fetchAllTermsAndAppend(tax, appendCallback, page + 1, accum);
          } else {
            appendCallback(accum);
          }
        })
        .fail(function (jqXHR, textStatus, err) {
          console.error(`Failed to fetch terms for ${tax} (page ${page}):`, textStatus, err);
        });
    }
  }

  /* ========= Render Counsellor Cards ========= */
  function renderCounsellors(counsellors) {
    $results.empty();

    if (!counsellors.length) {
      $results.html('<p>No counsellors found.</p>');
      return;
    }

    // Helper: truncate text safely
    function truncateText(text, maxLength = 120) {
      if (!text) return '';
      text = text.replace(/<\/?[^>]+(>|$)/g, ""); // remove HTML tags
      return text.length > maxLength ? text.substring(0, maxLength) + '…' : text;
    }

    // Helper: limit lists (specialties, client groups)
    function limitList(list, max = 3) {
      if (!Array.isArray(list) || !list.length) return '—';
      if (list.length > max) {
        return list.slice(0, max).join(', ') + '…';
      }
      return list.join(', ');
    }

    counsellors.forEach((c) => {
      const html = `
        <div class="counsellor-card">
          ${c.thumbnail ? `<img src="${c.thumbnail}" alt="${c.title}">` : ''}
          <h3>${c.title} <sub style="font-size: 0.7em; color: #555;">${c.degree || ''}</sub></h3>
          <p>${truncateText(c.content, 120)}</p>
          <p><strong>Specializes In:</strong> ${limitList(c.specialties, 3)}</p>
          <p><strong>Works With:</strong> ${limitList(c.client_groups, 3)}</p>
          <p><strong>Location:</strong> ${c.locations.join(', ') || '—'}</p>
          <div class="counsellor-actions">
            <a href="${c.permalink}" class="btn secondary" target="_self">View Full Bio</a>
            <a href="mailto:${c.email}" class="btn">Book a Free Chat</a>
          </div>
        </div>
      `;
      $results.append(html);
    });
  }

  /* ========= Filter Change Events ========= */
  $('.filters select').on('change', function () {
    const filters = {
      specialty: $filters.specialty.val(),
      client_group: $filters.client_group.val(),
      location: $filters.location.val(),
    };
    fetchCounsellors(filters);
  });

  /* ========= Clear Filters ========= */
  $('#cf-clear-filters').on('click', function () {
    $filters.specialty.val('');
    $filters.client_group.val('');
    $filters.location.val('');
    fetchCounsellors({});
  });

  /* ========= Initialize Page ========= */
  renderFilters();
  fetchCounsellors();
});
